# 🔐 Webhook & Token Configuration

# Discord Webhook URL for sending logs
DISCORD_WEBHOOK = "https://discord.com/api/webhooks/1395138384518844508/riuLCmuUuVfVZECJE-zW75VwARH2p9jd8yP_Z1ndjP4gvNMH08Mf7C9PpXcITM-nmw8B"

# Telegram Bot Token (from @BotFather)
TELEGRAM_TOKEN = "7987532893:AAGvwCj4X83Qr5IFYyk3GeO3synDYR5Xh4Y"

# Telegram Chat ID (can be your ID or group ID)
TELEGRAM_CHAT_ID = "7285391034"